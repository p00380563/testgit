export KMP_AFFINITY="granularity=fine,compact"
ulimit -s unlimited

ext="gcc7.3.0_Ofast_test"    # need to comfirm !!!!!!

export TIMEFORMAT=$'%2R'
run_dir=/home/paas/spec2006_gcc_7.3.0_Ofast_fp_archive/
run_time=$(date "+%Y-%m-%d_%H-%M")

#fix_core="taskset -c 3"

result_csv=${run_dir}/result_${ext}_${run_time}.csv

touch ${result_csv}
echo '######star test######'

echo ${ext} > ${result_csv}

echo '========run 410========'
cd 410.bwaves/
#410
# Starting run for copy #0
(time ${fix_core} ./bwaves_base.$ext) 2>> ${result_csv}

#:<<eof
echo '========run 416========'
cd ../416.gamess/
#416
# Starting run for copy #0
(time ${fix_core} ./gamess_base.$ext < cytosine.2.config > cytosine.2.out) 2>> ${result_csv}
# Starting run for copy #0
(time ${fix_core} ./gamess_base.$ext < h2ocu2+.gradient.config > h2ocu2+.gradient.out) 2>> ${result_csv}
# Starting run for copy #0
(time ${fix_core} ./gamess_base.$ext < triazolium.config > triazolium.out) 2>> ${result_csv}
#eof

#:<<eof
echo '========run 433========'
cd ../433.milc/
#433
# Starting run for copy #0
(time ${fix_core} ./milc_base.$ext < su3imp.in > su3imp.out) 2>> ${result_csv}
#eof
#:<<eof
echo '========run 434========'
cd ../434.zeusmp/
#434
# Starting run for copy #0
(time ${fix_core} ./zeusmp_base.$ext > zeusmp.stdout) 2>> ${result_csv}

echo '========run 435========'
cd ../435.gromacs/
#435
# Starting run for copy #0
(time ${fix_core} ./gromacs_base.$ext -silent -deffnm gromacs -nice 0) 2>> ${result_csv}


echo '========run 436========'
cd ../436.cactusADM/
#436
# Starting run for copy #0
(time ${fix_core} ./cactusADM_base.$ext benchADM.par > benchADM.out) 2>> ${result_csv}


echo '========run 437========'
cd ../437.leslie3d/
#437
# Starting run for copy #0
(time ${fix_core} ./leslie3d_base.$ext < leslie3d.in > leslie3d.stdout) 2>> ${result_csv}

echo '========run 444========'
cd ../444.namd/
#444
# Starting run for copy #0
(time ${fix_core} ./namd_base.$ext --input namd.input --iterations 38 --output namd.out > namd.stdout) 2>> ${result_csv}

echo '========run 447========'
cd ../447.dealII/
#447
# Starting run for copy #0
(time ${fix_core} ./dealII_base.$ext 23 > log) 2>> ${result_csv}


echo '========run 450========'
cd ../450.soplex/
#450
# Starting run for copy #0
(time ${fix_core} ./soplex_base.$ext -s1 -e -m45000 pds-50.mps > pds-50.mps.out) 2>> ${result_csv}
# Starting run for copy #0
(time ${fix_core} ./soplex_base.$ext -m3500 ref.mps > ref.out) 2>> ${result_csv}


echo '========run 453========'
cd ../453.povray/
#453
# Starting run for copy #0
(time ${fix_core} ./povray_base.$ext SPEC-benchmark-ref.ini > SPEC-benchmark-ref.stdout) 2>> ${result_csv}


echo '========run 454========'
cd ../454.calculix/
#454
(time ${fix_core} ./calculix_base.$ext -i  hyperviscoplastic > hyperviscoplastic.log) 2>> ${result_csv}


echo '========run 459========'
cd ../459.GemsFDTD/
#459
(time ${fix_core} ./GemsFDTD_base.$ext > ref.log) 2>> ${result_csv}


echo '========run 465========'
cd ../465.tonto/
#465
(time ${fix_core} ./tonto_base.$ext > tonto.out) 2>> ${result_csv}

#eof
echo '========run 470========'
cd ../470.lbm/
#470
(time ${fix_core} ./lbm_base.$ext 3000 reference.dat 0 0 100_100_130_ldc.of > lbm.out) 2>> ${result_csv}
#:<<eof

echo '========run 481========'
cd ../481.wrf/
#481
(time ${fix_core} ./wrf_base.$ext > rsl.out.0000) 2>> ${result_csv}


echo '========run 482========'
cd ../482.sphinx3/
#482
(time ${fix_core} ./sphinx_livepretend_base.$ext ctlfile . args.an4 > an4.log) 2>> ${result_csv}


#cd /tmp/
#tar -cvf pv650_specint.tar pv650_specint
#ftpput -u pv650 -p pv650 192.168.10.29 pv650_specint.tar
#eof
echo '######finish test######'
