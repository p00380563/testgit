export KMP_AFFINITY="granularity=fine,compact"
ulimit -s unlimited

export TIMEFORMAT=$'%2R'
result_dir=/home/paas/spec2006_gcc_7.3.0_Ofast_fp_archive/
run_time=$(date "+%Y-%m-%d_%H-%M")

#fix_core="taskset -c 3"

Core_NUM=$[$1-1]
run_core=$1
ext="gcc7.3.0_Ofast_test"

result_csv=${result_dir}/result_${ext}_${run_core}cores_${run_time}.csv
#result_csv=./result_${ext}_${Core_NUM}cores_${run_time}.csv

touch ${result_csv}
echo '######start test#######'
echo ${ext} > ${result_csv}
:<<eof
echo '410.bwaves' >> ${result_csv}


echo '========run 410========'
cd 410.bwaves/

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../410.bwaves_${i} ];then

		rm -rf ../410.bwaves_${i}/*
	else
		mkdir ../410.bwaves_${i}
	fi
	cp -r * ../410.bwaves_${i}/
    }&
done
wait

# Starting run for copy #0
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../410.bwaves_${i}
	(time taskset -c $i ./bwaves_base.$ext) 2>> ${result_csv}
    }&
done
wait

cd ../416.gamess/
echo '========run 416========'
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../416.gamess_${i} ];then

		rm -rf ../416.gamess_${i}/*
	else
		mkdir ../416.gamess_${i}
	fi
	cp -r * ../416.gamess_${i}/
    }&
done
wait

# Starting run for copy #0
echo '416.cytosine' >> ${result_csv}
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../416.gamess_${i}
	(time taskset -c $i ./gamess_base.$ext < cytosine.2.config > cytosine.2.out) 2>> ${result_csv}
    }&
done
wait

echo '416.h2ocu2' >> ${result_csv}
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../416.gamess_${i}
	# Starting run for copy #0
	(time taskset -c $i ./gamess_base.$ext < h2ocu2+.gradient.config > h2ocu2+.gradient.out) 2>> ${result_csv}
    }&
done 
wait

echo '416.gamess_base' >> ${result_csv}
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../416.gamess_${i}
	# Starting run for copy #0
	(time taskset -c $i ./gamess_base.$ext < triazolium.config > triazolium.out) 2>> ${result_csv}
    }&
done
wait

#:<<eof
echo '========run 433========'
echo '433.milc' >> ${result_csv}
cd ../433.milc/

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../433.milc_${i} ];then

		rm -rf ../433.milc_${i}/*
	else
		mkdir ../433.milc_${i}
	fi
	cp -r * ../433.milc_${i}/
    }&
done
wait

for (( i=0; i<=$Core_NUM; i++ ))
do
#433
# Starting run for copy #0
    {
	cd ../433.milc_${i}
	(time taskset -c $i ./milc_base.$ext < su3imp.in > su3imp.out) 2>> ${result_csv}
    }&
done
wait

echo '========run 434========'
echo '434.zeusmp' >> ${result_csv}
cd ../434.zeusmp/

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../434.zeusmp_${i} ];then

		rm -rf ../434.zeusmp_${i}/*
	else
		mkdir ../434.zeusmp_${i}
	fi
	cp -r * ../434.zeusmp_${i}/
    }&
done
wait

# Starting run for copy #0
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../434.zeusmp_${i}
	(time taskset -c $i ./zeusmp_base.$ext > zeusmp.stdout) 2>> ${result_csv}
    }&
done
wait

echo '========run 435========'	
echo '435.gromacs' >> ${result_csv}
cd ../435.gromacs/

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../435.gromacs_${i} ];then

		rm -rf ../435.gromacs_${i}/*
	else
		mkdir ../435.gromacs_${i}
	fi
	cp -r * ../435.gromacs_${i}/
    }&
done
wait

# Starting run for copy #0
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../435.gromacs_${i}
	(time taskset -c $i ./gromacs_base.$ext -silent -deffnm gromacs -nice 0) 2>> ${result_csv}
    }&
done
wait


echo '========run 436========'
echo '436.cactusADM' >> ${result_csv}
cd ../436.cactusADM/

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../436.cactusADM_${i} ];then

		rm -rf ../436.cactusADM_${i}/*
	else
		mkdir ../436.cactusADM_${i}
	fi
	cp -r * ../436.cactusADM_${i}/
    }&
done
wait
# Starting run for copy #0
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../436.cactusADM_${i}
	(time taskset -c $i ./cactusADM_base.$ext benchADM.par > benchADM.out) 2>> ${result_csv}
    }&
done
wait

echo '========run 437========'
echo '437.leslie3d' >> ${result_csv}
cd ../437.leslie3d/
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../437.leslie3d_${i} ];then

		rm -rf ../437.leslie3d_${i}/*
	else
		mkdir ../437.leslie3d_${i}
	fi
	cp -r * ../437.leslie3d_${i}/
    }&
done
wait
# Starting run for copy #0
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../437.leslie3d_${i}
	(time taskset -c $i ./leslie3d_base.$ext < leslie3d.in > leslie3d.stdout) 2>> ${result_csv}
    }&
done
wait

echo '========run 444========'
echo '444.namd' >> ${result_csv}
cd ../444.namd/
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../444.namd_${i} ];then

		rm -rf ../444.namd_${i}/*
	else
		mkdir ../444.namd_${i}
	fi
	cp -r * ../444.namd_${i}/
    }&
done
wait
# Starting run for copy #0
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../444.namd_${i}
	(time taskset -c $i ./namd_base.$ext --input namd.input --iterations 38 --output namd.out > namd.stdout) 2>> ${result_csv}
    }&
done
wait

echo '========run 447========'
echo '447.dealII' >> ${result_csv}
cd ../447.dealII/
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../447.dealII_${i} ];then

		rm -rf ../447.dealII_${i}/*
	else
		mkdir ../447.dealII_${i}
	fi
	cp -r * ../447.dealII_${i}/
    }&
done
wait
# Starting run for copy #0
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../447.dealII_${i}
	(time taskset -c $i ./dealII_base.$ext 23 > log) 2>> ${result_csv}
    }&
done
wait

eof

echo '========run 450========'
echo '450.soplex_pds-50' >> ${result_csv}
cd 450.soplex/
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../450.soplex_${i} ];then

		rm -rf ../450.soplex_${i}/*
	else
		mkdir ../450.soplex_${i}
	fi
	cp -r * ../450.soplex_${i}/
    }&
done
wait
# Starting run for copy #0
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../450.soplex_${i}
	(time taskset -c $i ./soplex_base.$ext -s1 -e -m45000 pds-50.mps > pds-50.mps.out) 2>> ${result_csv}
    }&
done
wait

# Starting run for copy #0
echo '450.soplex_ref.mps' >> ${result_csv}
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../450.soplex_${i}
	(time taskset -c $i ./soplex_base.$ext -m3500 ref.mps > ref.out) 2>> ${result_csv}
    }&
done
wait

:<<eof
echo '========run 453========'
echo '453.povray' >> ${result_csv}
cd ../453.povray/
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../453.povray_${i} ];then

		rm -rf ../453.povray_${i}/*
	else
		mkdir ../453.povray_${i}
	fi
	cp -r * ../453.povray_${i}/
    }&
done
wait
# Starting run for copy #0
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../453.povray_${i}
	(time taskset -c $i ./povray_base.$ext SPEC-benchmark-ref.ini > SPEC-benchmark-ref.stdout) 2>> ${result_csv}
    }&
done
wait

#eof

echo '========run 454========'
echo '454.calculix' >> ${result_csv}
cd ../454.calculix/

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../454.calculix_${i} ];then
		rm -rf ../454.calculix_${i}/*
	else
		mkdir ../454.calculix_${i}
	fi
        cp -r * ../454.calculix_${i}/
    }&
done
wait

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../454.calculix_${i}
	(time taskset -c $i ./calculix_base.$ext -i  hyperviscoplastic > hyperviscoplastic.log) 2>> ${result_csv}
    }&
done
wait

#:<<eof
echo '========run 459========'
echo '459.GemsFDTD' >> ${result_csv}
cd ../459.GemsFDTD/
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../459.GemsFDTD_${i} ];then
		rm -rf ../459.GemsFDTD_${i}/*
	else
		mkdir ../459.GemsFDTD_${i}
	fi
        cp -r * ../459.GemsFDTD_${i}/
    }&
done
wait
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../459.GemsFDTD_${i}
	(time  taskset -c $i ./GemsFDTD_base.$ext > ref.log) 2>> ${result_csv}
    }&
done
wait

echo '========run 465========'
echo '465.tonto' >> ${result_csv}
cd ../465.tonto/

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../465.tonto_${i} ];then
		rm -rf ../465.tonto_${i}/*
	else
		mkdir ../465.tonto_${i}
	fi
        cp -r * ../465.tonto_${i}/
    }&
done
wait

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../465.tonto_${i}
	(time taskset -c $i ./tonto_base.$ext > tonto.out) 2>> ${result_csv}
    }&
done
wait

echo '========run 470========'
echo '470.lbm' >> ${result_csv}
cd ../470.lbm/
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../470.lbm_${i} ];then
		rm -rf ../470.lbm_${i}/*
	else
		mkdir ../470.lbm_${i}
	fi
        cp -r * ../470.lbm_${i}/
    }&
done
wait
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../470.lbm_${i}
	(time taskset -c $i ./lbm_base.$ext 3000 reference.dat 0 0 100_100_130_ldc.of > lbm.out) 2>> ${result_csv}
    }&
done
wait

echo '========run 481========'
echo '4481.wrf' >> ${result_csv}
cd ../481.wrf/

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../481.wrf_${i} ];then
		rm -rf ../481.wrf_${i}/*
	else
		mkdir ../481.wrf_${i}
	fi
        cp -r * ../481.wrf_${i}/
    }&
done
wait

for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../481.wrf_${i}
	(time taskset -c $i ./wrf_base.$ext > rsl.out.0000) 2>> ${result_csv}
    }&
done
wait

echo '========run 482========'
echo '482.sphinx3' >> ${result_csv}
cd ../482.sphinx3/
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	if [ -d ../482.sphinx3_${i} ];then
		rm -rf ../482.sphinx3_${i}/*
	else
		mkdir ../482.sphinx3_${i}
	fi
        cp -r * ../482.sphinx3_${i}/
    }&
done
wait
for (( i=0; i<=$Core_NUM; i++ ))
do
    {
	cd ../482.sphinx3_${i}
	(time taskset -c $i ./sphinx_livepretend_base.$ext ctlfile . args.an4 > an4.log) 2>> ${result_csv}
    }&
done
wait
eof

echo '#######finish etst######'
