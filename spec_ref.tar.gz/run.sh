ulimit -s unlimited
export KMP_AFFINITY="granularity=fine,compact"

ext="gcc7.3.0_Ofast_test"

ins_res=/home/l00347187/fp_log/${ext}_instructions
if [ -f ${ins_res} ];then
     rm -rf ${ins_res}
else
     touch ${ins_res}
fi

echo '========410======'
cd 410.bwaves/
#410
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3  ./bwaves_base.$ext 2>> ${ins_res}

#:<<eof
echo '========416======='
cd ../416.gamess/
#416
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./gamess_base.$ext < cytosine.2.config > cytosine.2.out 2>>  ${ins_res}
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./gamess_base.$ext < h2ocu2+.gradient.config > h2ocu2+.gradient.out 2>>  ${ins_res}
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./gamess_base.$ext < triazolium.config > triazolium.out 2>>  ${ins_res}
#eof

#:<<eof
echo '=========433==========='
cd ../433.milc/
#433
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./milc_base.$ext < su3imp.in > su3imp.out 2>>  ${ins_res}
#eof
#:<<eof
echo '=========434======='
cd ../434.zeusmp/
#434
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./zeusmp_base.$ext > zeusmp.stdout 2>>  ${ins_res}

echo '==========435========='
cd ../435.gromacs/
#435
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./gromacs_base.$ext -silent -deffnm gromacs -nice 0 2>>  ${ins_res}


echo '=========436========='
cd ../436.cactusADM/
#436
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./cactusADM_base.$ext benchADM.par > benchADM.out 2>>  ${ins_res}


echo '==========437========='
cd ../437.leslie3d/
#437
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./leslie3d_base.$ext < leslie3d.in > leslie3d.stdout 2>>  ${ins_res}

echo '==========444=========='
cd ../444.namd/
#444
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./namd_base.$ext --input namd.input --iterations 38 --output namd.out > namd.stdout 2>>  ${ins_res}

echo '==========447========='
cd ../447.dealII/
#447
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./dealII_base.$ext 23 > log 2>>  ${ins_res}


echo '==========450=========='
cd ../450.soplex/
#450
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./soplex_base.$ext -s1 -e -m45000 pds-50.mps > pds-50.mps.out 2>>  ${ins_res}
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./soplex_base.$ext -m3500 ref.mps > ref.out 2>>  ${ins_res}


echo '=========453========='
cd ../453.povray/
#453
# Starting run for copy #0
perf stat -e r074,r075,instructions taskset -c 3   ./povray_base.$ext SPEC-benchmark-ref.ini > SPEC-benchmark-ref.stdout 2>> ${ins_res}


echo '========454========'
cd ../454.calculix/
#454
perf stat -e r074,r075,instructions taskset -c 3   ./calculix_base.$ext -i  hyperviscoplastic > hyperviscoplastic.log 2>> ${ins_res}


echo '=========459========='
cd ../459.GemsFDTD/
#459
perf stat -e r074,r075,instructions taskset -c 3   ./GemsFDTD_base.$ext > ref.log 2>> ${ins_res}


echo '========465=========='
cd ../465.tonto/
#465
perf stat -e r074,r075,instructions taskset -c 3   ./tonto_base.$ext > tonto.out 2>>  ${ins_res}

echo '========470========'
cd ../470.lbm/
perf stat -e r074,r075,instructions taskset -c 3   ./lbm_base.$ext 3000 reference.dat 0 0 100_100_130_ldc.of > lbm.out 2>>  ${ins_res}

echo '========481========='
cd ../481.wrf/
#481
perf stat -e r074,r075,instructions taskset -c 3   ./wrf_base.$ext > rsl.out.0000 2>>  ${ins_res}

echo '========482========'
cd ../482.sphinx3/
#482
perf stat -e r074,r075,instructions taskset -c 3   ./sphinx_livepretend_base.$ext ctlfile . args.an4 > an4.log 2>>  ${ins_res}

cd ../../
echo '=========test end======='




